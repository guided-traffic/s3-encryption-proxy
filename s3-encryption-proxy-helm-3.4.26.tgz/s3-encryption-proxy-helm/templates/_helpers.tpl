{{/*
Expand the name of the chart.
*/}}
{{- define "s3-encryption-proxy.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "s3-encryption-proxy.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "s3-encryption-proxy.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "s3-encryption-proxy.labels" -}}
helm.sh/chart: {{ include "s3-encryption-proxy.chart" . }}
{{ include "s3-encryption-proxy.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "s3-encryption-proxy.selectorLabels" -}}
app.kubernetes.io/name: {{ include "s3-encryption-proxy.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "s3-encryption-proxy.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "s3-encryption-proxy.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Create the name of the config map
*/}}
{{- define "s3-encryption-proxy.configMapName" -}}
{{ include "s3-encryption-proxy.fullname" . }}-config
{{- end }}

{{/*
Create the name of the secret
*/}}
{{- define "s3-encryption-proxy.secretName" -}}
{{ include "s3-encryption-proxy.fullname" . }}-secrets
{{- end }}

{{/*
Create the name of the certificate
*/}}
{{- define "s3-encryption-proxy.certificateName" -}}
{{ include "s3-encryption-proxy.fullname" . }}-tls
{{- end }}

{{/*
Pod labels
*/}}
{{- define "s3-encryption-proxy.podLabels" -}}
{{- if .Values.podLabels }}
{{- toYaml .Values.podLabels }}
{{- end }}
{{- end }}
